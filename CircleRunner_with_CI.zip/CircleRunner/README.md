# Circle Runner (Android, Jetpack Compose)

Juego sencillo de esquivar obstáculos. Personaje **círculo** que salta al tocar la pantalla. Botón **Pausa/Reanudar**, **Puntaje** y **Mejor**.

## Compilar sin Android Studio (en la nube con GitHub Actions)
1. Crea un repositorio en GitHub y sube todo este proyecto.
2. Ve a **Actions** → aparecerá el workflow **Build Android APK (Cloud)**.
3. Haz click en **Run workflow** (botón verde).
4. Cuando termine, entra a **Actions → build → Summary** y baja el artefacto **CircleRunner-debug-apk**. Dentro está el `.apk`.
5. Pásalo a tu celular e instálalo (activa *Permitir apps de orígenes desconocidos*).

> El workflow instala SDK, Gradle 8.7, genera wrapper y compila `assembleDebug`.

## Compilar local (opcional)
Abre con Android Studio, sincroniza gradle y `Run ▶`.

Ajustes en `ui/GameScreen.kt` (gravedad/velocidad/salto y obstáculos).