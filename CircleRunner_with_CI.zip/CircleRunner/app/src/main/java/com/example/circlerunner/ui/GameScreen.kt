package com.example.circlerunner.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.isActive
import kotlinx.coroutines.yield
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

private data class Player(var x: Float, var y: Float, var radius: Float, var velY: Float)
private data class Obstacle(var x: Float, var y: Float, var width: Float, var height: Float)

@Composable
fun GameScreen() {
    val density = LocalDensity.current
    val groundHeightDp = 120.dp
    val gravity = with(density) { 1800f } // px/s^2
    val jumpVelocity = with(density) { -800f } // px/s
    val speed = with(density) { 300f } // px/s

    var paused by remember { mutableStateOf(false) }
    var score by remember { mutableStateOf(0) }
    var best by remember { mutableStateOf(0) }
    var gameOver by remember { mutableStateOf(false) }

    var player by remember { mutableStateOf(Player(0f, 0f, 0f, 0f)) }
    var obstacles by remember { mutableStateOf(listOf<Obstacle>()) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF101010))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Puntaje: $score", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Mejor: $best", color = Color.White, fontSize = 16.sp, modifier = Modifier.padding(end = 8.dp))
                Button(onClick = { paused = !paused }) {
                    Text(if (paused) "Reanudar" else "Pausa")
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 56.dp)
        ) {
            var canvasWidth by remember { mutableStateOf(0f) }
            var canvasHeight by remember { mutableStateOf(0f) }
            val groundY = remember(canvasHeight) {
                canvasHeight - with(density) { groundHeightDp.toPx() }
            }

            Canvas(modifier = Modifier
                .fillMaxSize()
                .pointerInput(paused, gameOver) {
                    detectTapGestures {
                        if (gameOver) return@detectTapGestures
                        val onGround = player.y + player.radius >= groundY - 1f
                        if (onGround && !paused) {
                            player = player.copy(velY = jumpVelocity)
                        }
                    }
                }
            ) {
                canvasWidth = size.width
                canvasHeight = size.height

                if (player.radius == 0f) {
                    val r = size.minDimension * 0.04f
                    player = Player(
                        x = size.width * 0.2f,
                        y = (groundY - r),
                        radius = r,
                        velY = 0f
                    )
                    obstacles = emptyList()
                    score = 0
                    gameOver = false
                }
            }

            LaunchedEffect(paused, gameOver, canvasWidth, canvasHeight) {
                var lastNanos = 0L
                while (isActive) {
                    val frameNanos = withFrameNanos { it }
                    if (lastNanos == 0L) { lastNanos = frameNanos; continue }
                    val dt = (frameNanos - lastNanos) / 1_000_000_000f
                    lastNanos = frameNanos

                    if (!paused && !gameOver && canvasWidth > 0f && canvasHeight > 0f) {
                        val groundYLocal = canvasHeight - with(density) { groundHeightDp.toPx() }

                        var newVelY = player.velY + gravity * dt
                        var newY = player.y + newVelY * dt

                        if (newY + player.radius >= groundYLocal) {
                            newY = groundYLocal - player.radius
                            newVelY = 0f
                        }

                        player = player.copy(y = newY, velY = newVelY)

                        var obs = obstacles.map { it.copy(x = it.x - speed * dt) }
                            .filter { it.x + it.width > 0f }

                        if (obs.isEmpty() || (obs.maxOf { it.x + it.width } < canvasWidth * 0.7f)) {
                            val h = 60f + Random.nextFloat() * 80f
                            val w = 40f + Random.nextFloat() * 60f
                            val x = max(canvasWidth, obs.maxOfOrNull { it.x + it.width } ?: 0f) + Random.nextFloat() * 300f + 200f
                            val y = groundYLocal - h
                            obs = obs + Obstacle(x, y, w, h)
                        }

                        val p = player
                        val collision = obs.any { rect ->
                            val cx = max(rect.x, min(p.x, rect.x + rect.width))
                            val cy = max(rect.y, min(p.y, rect.y + rect.height))
                            val dx = p.x - cx
                            val dy = p.y - cy
                            dx * dx + dy * dy <= p.radius * p.radius
                        }

                        if (collision) {
                            gameOver = true
                            best = max(best, score)
                        } else {
                            val passedBefore = obstacles.count { it.x + it.width < p.x }
                            val passedNow = obs.count { it.x + it.width < p.x }
                            if (passedNow > passedBefore) score += (passedNow - passedBefore)
                            obstacles = obs
                        }
                    }
                    yield()
                }
            }

            Canvas(modifier = Modifier.fillMaxSize()) {
                val groundYLocal = size.height - with(density) { groundHeightDp.toPx() }

                drawRect(Color(0xFF181818), size = size)
                drawRect(
                    Color(0xFF2A2A2A),
                    topLeft = Offset(0f, groundYLocal),
                    size = Size(size.width, size.height - groundYLocal)
                )
                if (player.radius > 0f) {
                    drawCircle(
                        color = Color(0xFF57E389),
                        radius = player.radius,
                        center = Offset(player.x, player.y)
                    )
                }
                obstacles.forEach { o ->
                    drawRect(
                        color = Color(0xFFE35D5D),
                        topLeft = Offset(o.x, o.y),
                        size = Size(o.width, o.height)
                    )
                }
                if (gameOver) {
                    drawRect(Color(0x99000000), size = size)
                }
            }

            if (gameOver) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("¡Game Over!", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                    Text("Puntaje: $score  ·  Mejor: $best", color = Color.White, fontSize = 18.sp)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = {
                        obstacles = emptyList()
                        score = 0
                        gameOver = false
                        player = player.copy(velY = 0f)
                    }) { Text("Reintentar") }
                }
            }
        }
    }
}